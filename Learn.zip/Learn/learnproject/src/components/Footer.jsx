export const Footer = () => {
  return (
    <>
      <div className="ticks"></div>
      <section id="spacer"></section>
    </>
  );
};
