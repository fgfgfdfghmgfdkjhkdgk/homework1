export const Header = () => {
  return (
    <section id="center">
      <div>
        <h1>Магазин</h1>
      </div>
    </section>
  );
};
