export const Main = ({ children }) => {
  return (
    <main>
      <div className="ticks">
          <h2>Каталог</h2>
          {children}
        </div>
    </main>
  );
};
