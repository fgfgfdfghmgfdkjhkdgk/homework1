import { useState } from 'react'
import './App.css'

function App() {
  const productsMock = [
    {
      title: "Samsung S25",
      description: "256 гигабайт",
      count: 10
    },
    {
      title: "Samsung S25 Ultra",
      description: "512 gigabytes",
      count: 5
    }
  ];

  return (
    <>
      <section id="center">
        <div>
          <h1>Магазин</h1>
        </div>
      </section>

      <main>
        <div className="ticks">
          <h2>Каталог</h2>
          
          <div>
            {productsMock.map((product) => (
              <div key={product.title}>
                <h3>{product.title}</h3>
                <p>{product.description}</p>
                <p>Количество: {product.count}</p>
              </div>
            ))}
          </div>

        </div>
      </main>

      <div className="ticks"></div>
      <section id="spacer"></section>
    </>
  )
}

export default App
