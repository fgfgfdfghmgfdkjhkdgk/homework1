export const productsMock = [
  {
    id: 1,
    title: "Samsung S25",
    description: "256 гигабайт"
  },
  {
    id: 2,
    title: "Samsung S25 Ultra",
    description: "512 gigabytes"
  }
];
