function App() {
  return (
    <div style={{ padding: '20px' }}>
      
//1
      <div>Привет</div>

//2
      <div>
        <p>1</p>
        <p>2</p>
      </div>

//3
      <div>
        <input имя /><br />
        <input фамилия /><br />
        <input отчество />
      </div>

//4
      <div>
        <ul>
          <li>1</li><li>2</li><li>3</li>
          <li></li><li>5</li><li>6</li>
          <li>7</li><li>8</li><li>9</li>
          <li>10</li>
        </ul>
      </div>

//5
      <div>
        <p className="blue">1</p>
        <p className="gray">2</p>
        <p className="red">3</p>
      </div>

    </div>
  );
}

export default App;
